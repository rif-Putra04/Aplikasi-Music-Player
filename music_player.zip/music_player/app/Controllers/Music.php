<?php

namespace App\Controllers;

class Music extends BaseController
{
    public function index()
    {
        return view('index_view');
    }
}
